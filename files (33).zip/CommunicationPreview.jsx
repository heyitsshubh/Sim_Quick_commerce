import { useState } from "react";

/* ── Inline icon components (replacing lucide-react for artifact) ── */
const Icon = ({ d, className = "", size = 20 }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d={d} />
  </svg>
);
const Newspaper = (p) => <Icon {...p} d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2M9 7h7M9 11h7M9 15h4" />;
const Zap = (p) => <Icon {...p} d="M13 2 3 14h9l-1 8 10-12h-9l1-8z" />;
const TrendingUp = (p) => <Icon {...p} d="m22 7-8.5 8.5-5-5L2 17" />;
const TrendingDown = (p) => <Icon {...p} d="m22 17-8.5-8.5-5 5L2 7" />;
const AlertTriangle = (p) => <Icon {...p} d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3ZM12 9v4M12 17h.01" />;
const Globe = (p) => <Icon {...p} d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20ZM2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />;
const Building2 = (p) => <Icon {...p} d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18ZM6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2M10 6h4M10 10h4M10 14h4M10 18h4" />;
const ShoppingCart = (p) => <Icon {...p} d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6M9 22a1 1 0 1 0 0-2 1 1 0 0 0 0 2ZM20 22a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z" />;
const Search = (p) => <Icon {...p} d="M11 3a8 8 0 1 0 0 16 8 8 0 0 0 0-16ZM21 21l-4.35-4.35" />;
const ChevronRight = (p) => <Icon {...p} d="m9 18 6-6-6-6" />;
const Clock = (p) => <Icon {...p} d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20ZM12 6v6l4 2" />;
const Tag = (p) => <Icon {...p} d="M12 2H2v10l9.29 9.29c.94.94 2.48.94 3.42 0l6.58-6.58c.94-.94.94-2.48 0-3.42L12 2ZM7 7h.01" />;
const X = (p) => <Icon {...p} d="M18 6 6 18M6 6l12 12" />;
const Bookmark = (p) => <Icon {...p} d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z" />;
const Share2 = (p) => <Icon {...p} d="M18 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM6 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM18 22a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM8.59 13.51l6.83 3.98M15.41 6.51l-6.82 3.98" />;
const ExternalLink = (p) => <Icon {...p} d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14 21 3" />;
const Trophy = (p) => <Icon {...p} d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6M18 9h1.5a2.5 2.5 0 0 0 0-5H18M4 22h16M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22M18 2H6v7a6 6 0 0 0 12 0V2Z" />;
const HelpCircle = (p) => <Icon {...p} d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20ZM9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3M12 17h.01" />;
const Lock = (p) => <Icon {...p} d="M19 11H5a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2ZM7 11V7a5 5 0 0 1 10 0v4" />;
const Unlock = (p) => <Icon {...p} d="M19 11H5a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2ZM8 11V7a4 4 0 0 1 8 0" />;

// ─── TYPES ──────────────────────
const TYPE_STYLES = {
  breaking: { label: "Breaking News", icon: Zap, bg: "bg-red-50", text: "text-red-700", border: "border-red-200", badge: "bg-red-100 text-red-700" },
  industry: { label: "Industry Update", icon: TrendingUp, bg: "bg-blue-50", text: "text-blue-700", border: "border-blue-200", badge: "bg-blue-100 text-blue-700" },
  regulation: { label: "Regulation", icon: AlertTriangle, bg: "bg-amber-50", text: "text-amber-700", border: "border-amber-200", badge: "bg-amber-100 text-amber-700" },
  competitor: { label: "Competitor Intel", icon: Building2, bg: "bg-violet-50", text: "text-violet-700", border: "border-violet-200", badge: "bg-violet-100 text-violet-700" },
  opportunity: { label: "Opportunity", icon: Globe, bg: "bg-emerald-50", text: "text-emerald-700", border: "border-emerald-200", badge: "bg-emerald-100 text-emerald-700" },
  internal: { label: "Company Update", icon: ShoppingCart, bg: "bg-slate-100", text: "text-slate-700", border: "border-slate-300", badge: "bg-slate-200 text-slate-700" },
};

const IMPACT_BADGE = {
  positive: { label: "Positive Impact", cls: "bg-emerald-100 text-emerald-700" },
  negative: { label: "Negative Impact", cls: "bg-red-100 text-red-700" },
  neutral: { label: "Neutral", cls: "bg-slate-100 text-slate-600" },
};

const ARTICLES = [
  { id:"1", type:"breaking", headline:"Zepto Raises $665M at $3.6B Valuation, Plans Aggressive Expansion", summary:"The quick commerce unicorn plans to double its dark store count in 6 months, intensifying competition across Tier-1 cities.", body:"Zepto has closed a massive $665 million funding round, valuing the company at $3.6 billion. The Mumbai-based startup plans to use the funds to double its dark store count from 350 to 700 across major Indian cities within the next six months.\n\nCEO Aadit Palicha stated that unit economics are improving dramatically as order volumes increase and the 10-minute delivery promise has resonated with urban consumers.\n\nThe aggressive expansion could reshape competitive dynamics in the quick commerce space, putting pressure on rivals to match store density and delivery speed.\n\nKey implications for your strategy:\n• Increased competition for dark store real estate in prime locations\n• Potential wage inflation for delivery riders and warehouse staff\n• Consumer expectations for 10-min delivery becoming the baseline", source:"Economic Times", date:"2025-01-15", round:1, impact:"negative", impactAreas:["Dark Stores","Delivery Fleet","Operations"], readTime:"3 min" },
  { id:"2", type:"regulation", headline:"FSSAI Mandates New Cold Chain Compliance for Quick Commerce Players", summary:"New regulations require all quick commerce companies to maintain documented cold chain processes for perishables by Q2 2025.", body:"The FSSAI has issued new guidelines requiring all quick commerce platforms to implement comprehensive cold chain documentation.\n\nKey requirements include:\n• Real-time temperature monitoring in all dark stores\n• Mandatory cold chain training for all warehouse staff\n• Digital audit trails for perishable goods\n• Quarterly compliance reports submitted to FSSAI\n\nCompanies have until June 2025 to comply. Non-compliance could result in penalties up to ₹5 lakhs per incident.", source:"FSSAI Circular", date:"2025-01-12", round:1, impact:"neutral", impactAreas:["Operations","Sourcing","Technology"], readTime:"2 min" },
  { id:"3", type:"industry", headline:"Quick Commerce Market in India Expected to Reach $5.5B by 2025-End", summary:"RedSeer report projects 50% YoY growth driven by Tier-1 city penetration and category expansion into non-grocery segments.", body:"RedSeer Strategy Consultants projects India's quick commerce market to reach $5.5 billion by end of 2025.\n\nKey findings:\n• Average order value increased from ₹350 to ₹490\n• Non-grocery categories now constitute 25% of orders\n• Monthly transacting users have grown 3x\n• Bangalore, Mumbai, and Delhi NCR account for 60% of orders", source:"RedSeer Consulting", date:"2025-01-10", round:1, impact:"positive", impactAreas:["Product Categories","Marketing","Pricing"], readTime:"3 min" },
  { id:"4", type:"competitor", headline:"Swiggy Instamart Launches 'Instamart Plus' Subscription at ₹99/month", summary:"New subscription offers free delivery, extra discounts, and priority service — aiming to lock in high-frequency users.", body:"Swiggy has launched Instamart Plus at ₹99/month offering free delivery on orders above ₹199, 5% extra discount, and priority support.\n\nEarly data suggests 30% of frequent users (4+ orders/month) have subscribed in pilot markets. This could pressure competitors to introduce similar loyalty mechanisms.", source:"Mint", date:"2025-01-08", round:1, impact:"negative", impactAreas:["Marketing","Pricing"], readTime:"2 min" },
  { id:"5", type:"opportunity", headline:"Government Subsidies Available for Electric Delivery Fleet Conversion", summary:"The FAME III scheme offers up to 40% subsidy on electric two-wheelers for last-mile delivery companies.", body:"The Ministry of Heavy Industries announced expanded FAME III subsidies:\n• Up to 40% subsidy on electric two-wheelers for delivery\n• Additional 10% subsidy for converting >50% of fleet\n• Tax benefits for EV charging infrastructure\n• Fast-track permits for EV-only fleets\n\nEstimated savings: ₹25,000-35,000 per vehicle over 3 years.", source:"Ministry of Heavy Industries", date:"2025-01-05", round:1, impact:"positive", impactAreas:["Delivery Fleet","Operations"], readTime:"2 min" },
  { id:"6", type:"internal", headline:"Monthly Performance Brief: January 2025 Market Landscape", summary:"Your strategy team's monthly briefing on key metrics, competitive movements, and recommended focus areas for this round.", body:"Monthly Strategy Brief — January 2025\n\nMarket Overview:\n• Market growth rate: 48% YoY\n• Average delivery time (industry): 14.2 minutes\n• Dark store density (top 3): 1 per 3.2 sq km in Tier-1\n• Consumer NPS (industry average): 42\n\nRecommended Focus Areas:\n• Establish strong foundation in core grocery categories\n• Invest in technology infrastructure early\n• Balance dark store count vs. operational efficiency\n• Monitor competitor pricing moves closely", source:"Strategy Team", date:"2025-01-01", round:1, impact:"neutral", impactAreas:[], readTime:"3 min" },
];

const FILTERS = [
  { id:"all", label:"All News" },
  { id:"breaking", label:"Breaking" },
  { id:"industry", label:"Industry" },
  { id:"regulation", label:"Regulation" },
  { id:"competitor", label:"Competitor" },
  { id:"opportunity", label:"Opportunity" },
  { id:"internal", label:"Company" },
];

// ─── NAV TABS ───────────────────
const NAV_TABS = [
  { name: "Profile", active: false },
  { name: "Business Plan", active: false },
  { name: "Decisions", active: false },
  { name: "Results", active: false },
  { name: "Analysis", active: false },
  { name: "Communication", active: true },
];

export default function CommunicationPreview() {
  const [activeFilter, setActiveFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedArticle, setSelectedArticle] = useState(null);
  const [bookmarked, setBookmarked] = useState(new Set());

  const filtered = ARTICLES.filter((a) => {
    const matchType = activeFilter === "all" || a.type === activeFilter;
    const matchSearch = !searchQuery || a.headline.toLowerCase().includes(searchQuery.toLowerCase()) || a.summary.toLowerCase().includes(searchQuery.toLowerCase());
    return matchType && matchSearch;
  });

  const toggleBookmark = (id) => {
    setBookmarked((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };

  const featured = ARTICLES.find((a) => a.type === "breaking");
  const rest = filtered.filter((a) => a.id !== featured?.id || activeFilter !== "all");

  // ── ARTICLE DETAIL ─────────────
  if (selectedArticle) {
    const st = TYPE_STYLES[selectedArticle.type];
    const TypeIcon = st.icon;
    return (
      <div className="min-h-screen bg-slate-50" style={{ fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" }}>
        <div className="max-w-5xl mx-auto py-4 px-4">
          {/* TopNav replica */}
          <div className="flex justify-center">
            <div className="flex items-center gap-2 px-3 py-3 rounded-2xl bg-white/70 border border-white/40 shadow-sm">
              {NAV_TABS.map((t) => (
                <button key={t.name} onClick={t.name === "Communication" ? () => setSelectedArticle(null) : undefined}
                  className={`relative flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all whitespace-nowrap ${t.active ? "text-white" : "text-black hover:text-blue-600"}`}>
                  {t.active && <span className="absolute inset-0 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-500 shadow-lg" />}
                  <span className="relative z-10">{t.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="max-w-3xl mx-auto px-4 py-6">
          <button onClick={() => setSelectedArticle(null)} className="flex items-center gap-2 text-sm text-slate-500 hover:text-blue-600 mb-6 transition-colors">
            <ChevronRight size={16} className="rotate-180" /> Back to News Feed
          </button>
          <article className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
            <div className={`${st.bg} ${st.border} border-b px-6 py-4`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${st.badge}`}><TypeIcon size={20} /></div>
                  <div>
                    <span className={`text-xs font-semibold uppercase tracking-wider ${st.text}`}>{st.label}</span>
                    <div className="flex items-center gap-3 text-xs text-slate-500 mt-0.5">
                      <span>{selectedArticle.source}</span><span>•</span><span>{selectedArticle.date}</span><span>•</span>
                      <span className="flex items-center gap-1"><Clock size={12} />{selectedArticle.readTime} read</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => toggleBookmark(selectedArticle.id)} className={`p-2 rounded-lg transition-colors ${bookmarked.has(selectedArticle.id) ? "bg-amber-100 text-amber-600" : "hover:bg-slate-100 text-slate-400"}`}><Bookmark size={20} /></button>
                  <button className="p-2 rounded-lg hover:bg-slate-100 text-slate-400"><Share2 size={20} /></button>
                </div>
              </div>
            </div>
            <div className="p-6 md:p-8">
              <h1 className="text-2xl font-bold text-slate-900 leading-tight mb-4">{selectedArticle.headline}</h1>
              <p className="text-base text-slate-600 mb-6 leading-relaxed">{selectedArticle.summary}</p>
              {selectedArticle.impact && (
                <div className="flex flex-wrap items-center gap-2 mb-6">
                  <span className={`px-3 py-1 text-xs font-semibold rounded-full ${IMPACT_BADGE[selectedArticle.impact].cls}`}>{IMPACT_BADGE[selectedArticle.impact].label}</span>
                  {selectedArticle.impactAreas?.map((a) => <span key={a} className="px-3 py-1 text-xs font-medium rounded-full bg-slate-100 text-slate-600">{a}</span>)}
                </div>
              )}
              <div className="border-t border-slate-100 pt-6">
                {selectedArticle.body.split("\n").map((para, i) =>
                  para.trim() ? (
                    para.startsWith("•") ? (
                      <div key={i} className="flex items-start gap-2 ml-4 mb-2"><span className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 shrink-0" /><p className="text-slate-700 leading-relaxed text-sm">{para.replace("•","").trim()}</p></div>
                    ) : <p key={i} className="text-slate-700 leading-relaxed mb-4">{para}</p>
                  ) : <div key={i} className="h-2" />
                )}
              </div>
            </div>
            <div className="border-t border-slate-100 px-6 py-4 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-slate-500"><Tag size={14} />Round {selectedArticle.round} News</div>
              <button onClick={() => setSelectedArticle(null)} className="text-sm text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1">Back to feed <ExternalLink size={14} /></button>
            </div>
          </article>
        </div>
      </div>
    );
  }

  // ── MAIN NEWS FEED ─────────────
  return (
    <div className="min-h-screen bg-slate-50" style={{ fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" }}>
      <div className="max-w-5xl mx-auto py-4 px-4">
        {/* TopNav replica */}
        <div className="flex justify-center">
          <div className="flex items-center gap-2 px-3 py-3 rounded-2xl bg-white/70 border border-white/40 shadow-sm overflow-x-auto">
            {NAV_TABS.map((t) => (
              <button key={t.name} className={`relative flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all whitespace-nowrap ${t.active ? "text-white" : "text-black hover:text-blue-600"}`}>
                {t.active && <span className="absolute inset-0 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-500 shadow-lg" />}
                <span className="relative z-10">{t.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Round header */}
        <div className="mt-4 bg-white border border-slate-200 rounded-lg shadow-sm px-4 py-4">
          <div className="flex items-start justify-between gap-6">
            <div className="flex-1 min-w-0">
              <h2 className="text-xl font-bold text-slate-900">Round 1 of 8</h2>
              <p className="text-sm text-slate-600 mt-1">Foundation: Fruits, dairy, cooking staples, snacks, beverages</p>
              <div className="flex items-center gap-2 overflow-x-auto pb-2 mt-3">
                {Array.from({length:8},(_,i)=>i+1).map((r)=>(
                  <div key={r} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap ${r===1?"bg-blue-600 text-white":r<1?"bg-green-100 text-green-700":"bg-slate-100 text-slate-400"}`}>
                    {r<=1?<Unlock size={14}/>:<Lock size={14}/>} Round {r}
                  </div>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-4">
              <button className="flex items-center gap-2 px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-medium rounded-md text-sm transition"><HelpCircle size={18} /><span className="hidden sm:inline">Game Guide</span></button>
              <div className="flex items-center gap-2 text-sm"><Trophy size={18} className="text-amber-500" /><span className="font-semibold text-slate-900">0 pts</span></div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-6">
        {/* Page title + search */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-gradient-to-br from-blue-600 to-blue-500 rounded-xl flex items-center justify-center shadow-sm"><Newspaper size={20} className="text-white" /></div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">News & Communication</h1>
              <p className="text-sm text-slate-500">Market intelligence and updates affecting your business</p>
            </div>
          </div>
          <div className="relative hidden md:block">
            <Search size={16} className="text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input type="text" placeholder="Search news…" value={searchQuery} onChange={(e)=>setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 w-56 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition" />
            {searchQuery && <button onClick={()=>setSearchQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"><X size={16} /></button>}
          </div>
        </div>



        {/* Featured article */}
        {activeFilter === "all" && featured && (
          <button onClick={()=>setSelectedArticle(featured)} className="w-full text-left mb-6 group">
            <div className={`relative overflow-hidden rounded-2xl border ${TYPE_STYLES[featured.type].border} ${TYPE_STYLES[featured.type].bg} p-6 transition-all hover:shadow-md`}>
              <div className="absolute top-4 right-4">
                <span className="flex items-center gap-1.5 px-3 py-1 bg-red-600 text-white text-xs font-bold rounded-full animate-pulse"><Zap size={12} />BREAKING</span>
              </div>
              <div className="max-w-2xl">
                <div className="flex items-center gap-2 text-xs text-slate-500 mb-3">
                  <span className="font-medium">{featured.source}</span><span>•</span><span>{featured.date}</span><span>•</span>
                  <span className="flex items-center gap-1"><Clock size={12} />{featured.readTime}</span>
                </div>
                <h2 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-blue-600 transition-colors leading-tight">{featured.headline}</h2>
                <p className="text-slate-600 leading-relaxed mb-4">{featured.summary}</p>
                <div className="flex flex-wrap items-center gap-2">
                  {featured.impact && <span className={`px-3 py-1 text-xs font-semibold rounded-full ${IMPACT_BADGE[featured.impact].cls}`}>{IMPACT_BADGE[featured.impact].label}</span>}
                  {featured.impactAreas?.map((a)=><span key={a} className="px-2.5 py-1 text-xs font-medium rounded-full bg-white/80 text-slate-600 border border-slate-200">{a}</span>)}
                  <span className="ml-auto text-sm text-blue-600 font-medium flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">Read full article <ChevronRight size={16} /></span>
                </div>
              </div>
            </div>
          </button>
        )}

        {/* News grid */}
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
          {rest.map((article)=>{
            const st = TYPE_STYLES[article.type];
            const TypeIcon = st.icon;
            return (
              <button key={article.id} onClick={()=>setSelectedArticle(article)} className="text-left group">
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden h-full flex flex-col transition-all hover:shadow-md hover:border-slate-300">
                  <div className={`${st.bg} ${st.border} border-b px-4 py-2.5 flex items-center justify-between`}>
                    <div className="flex items-center gap-2">
                      <TypeIcon size={16} className={st.text} />
                      <span className={`text-xs font-semibold uppercase tracking-wider ${st.text}`}>{st.label}</span>
                    </div>
                    <button onClick={(e)=>{e.stopPropagation();toggleBookmark(article.id);}}
                      className={`p-1 rounded transition-colors ${bookmarked.has(article.id)?"text-amber-500":"text-slate-300 hover:text-slate-500"}`}>
                      <Bookmark size={16} />
                    </button>
                  </div>
                  <div className="p-4 flex-1 flex flex-col">
                    <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
                      <span>{article.source}</span><span>•</span><span>{article.date}</span><span>•</span>
                      <span className="flex items-center gap-1"><Clock size={12} />{article.readTime}</span>
                    </div>
                    <h3 className="text-sm font-bold text-slate-900 mb-2 leading-snug group-hover:text-blue-600 transition-colors" style={{display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical",overflow:"hidden"}}>{article.headline}</h3>
                    <p className="text-xs text-slate-500 leading-relaxed flex-1" style={{display:"-webkit-box",WebkitLineClamp:3,WebkitBoxOrient:"vertical",overflow:"hidden"}}>{article.summary}</p>
                    <div className="flex flex-wrap items-center gap-1.5 mt-3 pt-3 border-t border-slate-100">
                      {article.impact && (
                        <span className={`px-2 py-0.5 text-[10px] font-semibold rounded-full flex items-center gap-0.5 ${IMPACT_BADGE[article.impact].cls}`}>
                          {article.impact==="positive"?<TrendingUp size={10}/>:article.impact==="negative"?<TrendingDown size={10}/>:null}
                          {article.impact}
                        </span>
                      )}
                      {article.impactAreas?.slice(0,2).map((a)=><span key={a} className="px-2 py-0.5 text-[10px] font-medium rounded-full bg-slate-100 text-slate-500">{a}</span>)}
                      {(article.impactAreas?.length||0)>2 && <span className="text-[10px] text-slate-400">+{article.impactAreas.length-2}</span>}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Empty state */}
        {filtered.length===0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4"><Newspaper size={32} className="text-slate-400" /></div>
            <h3 className="text-lg font-semibold text-slate-900 mb-1">No articles found</h3>
            <p className="text-sm text-slate-500">Try adjusting your filters or search query</p>
            <button onClick={()=>{setActiveFilter("all");setSearchQuery("");}} className="mt-4 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-xl hover:bg-blue-700 transition">Clear filters</button>
          </div>
        )}
      </div>
    </div>
  );
}
