/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState } from "react";
import TopNav from "../components/TopNav";
import RoundsStrip from "../components/RoundStrip";
import {
  HelpCircle,
  Trophy,
  Newspaper,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Zap,
  Globe,
  Building2,
  ShoppingCart,
  Search,
  ChevronRight,
  Clock,
  Tag,
  X,
  Bookmark,
  Share2,
  ExternalLink,
} from "lucide-react";

// ─── TYPES ───────────────────────────────────────────────
type ArticleType =
  | "breaking"
  | "industry"
  | "regulation"
  | "competitor"
  | "opportunity"
  | "internal";

type Article = {
  id: string;
  type: ArticleType;
  headline: string;
  summary: string;
  body: string;
  source: string;
  date: string;
  round: number;
  impact?: "positive" | "negative" | "neutral";
  impactAreas?: string[];
  readTime: string;
};

// ─── STYLE MAP ───────────────────────────────────────────
const TYPE_STYLES: Record<
  ArticleType,
  {
    label: string;
    icon: any;
    bg: string;
    text: string;
    border: string;
    badge: string;
  }
> = {
  breaking: {
    label: "Breaking News",
    icon: Zap,
    bg: "bg-red-50",
    text: "text-red-700",
    border: "border-red-200",
    badge: "bg-red-100 text-red-700",
  },
  industry: {
    label: "Industry Update",
    icon: TrendingUp,
    bg: "bg-blue-50",
    text: "text-blue-700",
    border: "border-blue-200",
    badge: "bg-blue-100 text-blue-700",
  },
  regulation: {
    label: "Regulation",
    icon: AlertTriangle,
    bg: "bg-amber-50",
    text: "text-amber-700",
    border: "border-amber-200",
    badge: "bg-amber-100 text-amber-700",
  },
  competitor: {
    label: "Competitor Intel",
    icon: Building2,
    bg: "bg-violet-50",
    text: "text-violet-700",
    border: "border-violet-200",
    badge: "bg-violet-100 text-violet-700",
  },
  opportunity: {
    label: "Opportunity",
    icon: Globe,
    bg: "bg-emerald-50",
    text: "text-emerald-700",
    border: "border-emerald-200",
    badge: "bg-emerald-100 text-emerald-700",
  },
  internal: {
    label: "Company Update",
    icon: ShoppingCart,
    bg: "bg-slate-50",
    text: "text-slate-700",
    border: "border-slate-300",
    badge: "bg-slate-200 text-slate-700",
  },
};

const IMPACT_BADGE: Record<string, { label: string; cls: string }> = {
  positive: {
    label: "Positive Impact",
    cls: "bg-emerald-100 text-emerald-700",
  },
  negative: { label: "Negative Impact", cls: "bg-red-100 text-red-700" },
  neutral: { label: "Neutral", cls: "bg-slate-100 text-slate-600" },
};

// ─── SAMPLE DATA (replace with API later) ────────────────
const SAMPLE_ARTICLES: Article[] = [
  {
    id: "1",
    type: "breaking",
    headline:
      "Zepto Raises $665M at $3.6B Valuation, Plans Aggressive Expansion",
    summary:
      "The quick commerce unicorn plans to double its dark store count in 6 months, intensifying competition across Tier-1 cities.",
    body: `Zepto has closed a massive $665 million funding round, valuing the company at $3.6 billion. The Mumbai-based startup plans to use the funds to double its dark store count from 350 to 700 across major Indian cities within the next six months.\n\nCEO Aadit Palicha stated: "We're seeing unit economics improve dramatically as order volumes increase. Our 10-minute delivery promise has resonated with urban consumers."\n\nThe aggressive expansion could reshape competitive dynamics in the quick commerce space, putting pressure on rivals to match store density and delivery speed. Industry analysts expect this to trigger a new round of investment across the sector.\n\nKey implications for your strategy:\n• Increased competition for dark store real estate in prime locations\n• Potential wage inflation for delivery riders and warehouse staff\n• Consumer expectations for 10-min delivery becoming the baseline`,
    source: "Economic Times",
    date: "2025-01-15",
    round: 1,
    impact: "negative",
    impactAreas: ["Dark Stores", "Delivery Fleet", "Operations"],
    readTime: "3 min",
  },
  {
    id: "2",
    type: "regulation",
    headline:
      "FSSAI Mandates New Cold Chain Compliance for Quick Commerce Players",
    summary:
      "New regulations require all quick commerce companies to maintain documented cold chain processes for perishables by Q2 2025.",
    body: `The Food Safety and Standards Authority of India (FSSAI) has issued new guidelines requiring all quick commerce and food delivery platforms to implement comprehensive cold chain documentation and compliance systems.\n\nKey requirements include:\n• Real-time temperature monitoring in all dark stores\n• Mandatory cold chain training for all warehouse staff\n• Digital audit trails for perishable goods from sourcing to delivery\n• Quarterly compliance reports submitted to FSSAI\n\nCompanies have until June 2025 to comply. Non-compliance could result in penalties up to ₹5 lakhs per incident and potential suspension of operations.\n\nThis regulation is expected to increase operational costs by 8-12% for perishable categories but will also improve consumer trust and reduce food waste.`,
    source: "FSSAI Circular",
    date: "2025-01-12",
    round: 1,
    impact: "neutral",
    impactAreas: ["Operations", "Sourcing", "Technology"],
    readTime: "2 min",
  },
  {
    id: "3",
    type: "industry",
    headline:
      "Quick Commerce Market in India Expected to Reach $5.5B by 2025-End",
    summary:
      "RedSeer report projects 50% YoY growth driven by Tier-1 city penetration and category expansion into non-grocery segments.",
    body: `A new report by RedSeer Strategy Consultants projects India's quick commerce market to reach $5.5 billion by the end of 2025, growing at approximately 50% year-over-year.\n\nKey findings from the report:\n• Average order value has increased from ₹350 to ₹490 over the past year\n• Non-grocery categories now constitute 25% of total quick commerce orders\n• Monthly transacting users have grown 3x in the past 18 months\n• Bangalore, Mumbai, and Delhi NCR account for 60% of all quick commerce orders\n\nThe report highlights that consumer behavior is shifting from "top-up" grocery runs to "primary shopping" via quick commerce, a trend that significantly increases the addressable market.\n\nCategory expansion into electronics, beauty, and pharmacy is expected to be the primary growth driver in the next 12 months.`,
    source: "RedSeer Consulting",
    date: "2025-01-10",
    round: 1,
    impact: "positive",
    impactAreas: ["Product Categories", "Marketing", "Pricing"],
    readTime: "3 min",
  },
  {
    id: "4",
    type: "competitor",
    headline:
      "Swiggy Instamart Launches 'Instamart Plus' Subscription at ₹99/month",
    summary:
      "New subscription offers free delivery, extra discounts, and priority service — aiming to lock in high-frequency users.",
    body: `Swiggy has launched "Instamart Plus," a subscription service priced at ₹99 per month that offers free delivery on all orders above ₹199, an additional 5% discount on select categories, and priority customer support.\n\nThe subscription is being rolled out first in Bangalore and Mumbai, with plans to expand to all cities within 8 weeks.\n\nEarly data suggests 30% of frequent Instamart users (4+ orders/month) have already subscribed in pilot markets. The move is aimed at increasing customer stickiness and raising average order frequency.\n\nThis could pressure other quick commerce players to introduce similar loyalty mechanisms or risk losing high-value repeat customers.`,
    source: "Mint",
    date: "2025-01-08",
    round: 1,
    impact: "negative",
    impactAreas: ["Marketing", "Pricing"],
    readTime: "2 min",
  },
  {
    id: "5",
    type: "opportunity",
    headline:
      "Government Subsidies Available for Electric Delivery Fleet Conversion",
    summary:
      "The FAME III scheme offers up to 40% subsidy on electric two-wheelers for last-mile delivery companies.",
    body: `The Ministry of Heavy Industries has announced an expanded FAME III (Faster Adoption and Manufacturing of Electric Vehicles) scheme that offers significant subsidies for commercial electric vehicle adoption.\n\nFor quick commerce and delivery companies:\n• Up to 40% subsidy on electric two-wheelers used for delivery\n• Additional 10% subsidy for companies converting more than 50% of their fleet\n• Tax benefits under Section 80EEB for EV charging infrastructure\n• Fast-track permits for EV-only delivery fleets in congested zones\n\nThis presents a significant opportunity to reduce delivery fleet costs while improving sustainability metrics. Companies that move early can lock in subsidies before the allocated budget is exhausted.\n\nEstimated savings: ₹25,000-35,000 per vehicle over 3 years.`,
    source: "Ministry of Heavy Industries",
    date: "2025-01-05",
    round: 1,
    impact: "positive",
    impactAreas: ["Delivery Fleet", "Operations"],
    readTime: "2 min",
  },
  {
    id: "6",
    type: "internal",
    headline:
      "Monthly Performance Brief: January 2025 Market Landscape",
    summary:
      "Your strategy team's monthly briefing on key metrics, competitive movements, and recommended focus areas.",
    body: `Monthly Strategy Brief — January 2025\n\nMarket Overview:\nThe quick commerce sector continues its rapid growth trajectory. Key metrics to watch:\n• Market growth rate: 48% YoY\n• Average delivery time (industry): 14.2 minutes\n• Average dark store density (top 3 players): 1 per 3.2 sq km in Tier-1 cities\n• Consumer NPS (industry average): 42\n\nCompetitive Positioning:\nAll major players are investing heavily in dark store expansion and technology. The focus has shifted from pure speed to a combination of speed + selection + reliability.\n\nRecommended Focus Areas This Round:\n1. Establish strong foundation in core grocery categories\n2. Invest in technology infrastructure early — it compounds\n3. Balance dark store count vs. operational efficiency\n4. Monitor competitor pricing moves closely\n\nRemember: Decisions made in early rounds create the foundation for later success. Think about which capabilities you want to build before the market gets crowded.`,
    source: "Strategy Team",
    date: "2025-01-01",
    round: 1,
    impact: "neutral",
    impactAreas: [],
    readTime: "3 min",
  },
];

// ─── FILTER OPTIONS ──────────────────────────────────────
const FILTER_OPTIONS: { id: ArticleType | "all"; label: string }[] = [
  { id: "all", label: "All News" },
  { id: "breaking", label: "Breaking" },
  { id: "industry", label: "Industry" },
  { id: "regulation", label: "Regulation" },
  { id: "competitor", label: "Competitor" },
  { id: "opportunity", label: "Opportunity" },
  { id: "internal", label: "Company" },
];

// ═══════════════════════════════════════════════════════════
//  MAIN COMPONENT
// ═══════════════════════════════════════════════════════════
export default function Communication() {
  const [activeFilter, setActiveFilter] = useState<ArticleType | "all">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [bookmarked, setBookmarked] = useState<Set<string>>(new Set());

  const filtered = SAMPLE_ARTICLES.filter((a) => {
    const matchesType = activeFilter === "all" || a.type === activeFilter;
    const matchesSearch =
      !searchQuery ||
      a.headline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.summary.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  const toggleBookmark = (id: string) => {
    setBookmarked((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const featuredArticle =
    SAMPLE_ARTICLES.find((a) => a.type === "breaking") || SAMPLE_ARTICLES[0];
  const restArticles = filtered.filter(
    (a) => a.id !== featuredArticle?.id || activeFilter !== "all"
  );

  // ─── ARTICLE DETAIL VIEW ──────────────────────────────
  if (selectedArticle) {
    const style = TYPE_STYLES[selectedArticle.type];
    const Icon = style.icon;

    return (
      <div className="min-h-screen bg-slate-50">
        <div className="max-w-7xl mx-auto py-4">
          <TopNav />
        </div>

        <div className="max-w-4xl mx-auto px-6 py-6">
          <button
            onClick={() => setSelectedArticle(null)}
            className="flex items-center gap-2 text-sm text-slate-500 hover:text-blue-600 mb-6 transition-colors"
          >
            <ChevronRight className="w-4 h-4 rotate-180" />
            Back to News Feed
          </button>

          <article className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
            {/* Header band */}
            <div className={`${style.bg} ${style.border} border-b px-6 py-4`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center ${style.badge}`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <span
                      className={`text-xs font-semibold uppercase tracking-wider ${style.text}`}
                    >
                      {style.label}
                    </span>
                    <div className="flex items-center gap-3 text-xs text-slate-500 mt-0.5">
                      <span>{selectedArticle.source}</span>
                      <span>•</span>
                      <span>{selectedArticle.date}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {selectedArticle.readTime} read
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => toggleBookmark(selectedArticle.id)}
                    className={`p-2 rounded-lg transition-colors ${
                      bookmarked.has(selectedArticle.id)
                        ? "bg-amber-100 text-amber-600"
                        : "hover:bg-slate-100 text-slate-400"
                    }`}
                  >
                    <Bookmark className="w-5 h-5" />
                  </button>
                  <button className="p-2 rounded-lg hover:bg-slate-100 text-slate-400 transition-colors">
                    <Share2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Body */}
            <div className="p-6 md:p-8">
              <h1 className="text-2xl md:text-3xl font-bold text-slate-900 leading-tight mb-4">
                {selectedArticle.headline}
              </h1>

              <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                {selectedArticle.summary}
              </p>

              {selectedArticle.impact && (
                <div className="flex flex-wrap items-center gap-2 mb-6">
                  <span
                    className={`px-3 py-1 text-xs font-semibold rounded-full ${
                      IMPACT_BADGE[selectedArticle.impact].cls
                    }`}
                  >
                    {IMPACT_BADGE[selectedArticle.impact].label}
                  </span>
                  {selectedArticle.impactAreas?.map((area) => (
                    <span
                      key={area}
                      className="px-3 py-1 text-xs font-medium rounded-full bg-slate-100 text-slate-600"
                    >
                      {area}
                    </span>
                  ))}
                </div>
              )}

              <div className="border-t border-slate-100 pt-6">
                {selectedArticle.body.split("\n").map((para, i) =>
                  para.trim() ? (
                    para.startsWith("•") ? (
                      <div key={i} className="flex items-start gap-2 ml-4 mb-2">
                        <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 shrink-0" />
                        <p className="text-slate-700 leading-relaxed text-sm">
                          {para.replace("•", "").trim()}
                        </p>
                      </div>
                    ) : (
                      <p
                        key={i}
                        className="text-slate-700 leading-relaxed mb-4"
                      >
                        {para}
                      </p>
                    )
                  ) : (
                    <div key={i} className="h-2" />
                  )
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="border-t border-slate-100 px-6 py-4 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Tag className="w-3.5 h-3.5" />
                Round {selectedArticle.round} News
              </div>
              <button
                onClick={() => setSelectedArticle(null)}
                className="text-sm text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"
              >
                Back to feed
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </article>
        </div>
      </div>
    );
  }

  // ─── NEWS FEED VIEW ────────────────────────────────────
  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto py-4">
        <TopNav />

        {/* Round header — same pattern as Analysis page */}
        <div className="mt-4 bg-white border border-slate-200 rounded-lg shadow-sm px-4 py-4">
          <div className="max-w-7xl mx-auto flex items-start justify-between gap-6">
            <div className="flex-1 min-w-0">
              <h2 className="text-xl font-bold text-slate-900">
                Round 1 of 8
              </h2>
              <p className="text-sm text-slate-600 mt-1">
                Foundation: Fruits, dairy, cooking staples, snacks, beverages
              </p>
              <div className="mt-3">
                <RoundsStrip currentRound={1} maxRounds={8} />
              </div>
            </div>

            <div className="flex items-center gap-4">
              <button className="flex items-center gap-2 px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-medium rounded-md transition">
                <HelpCircle className="w-5 h-5" />
                <span className="hidden sm:inline">Game Guide</span>
              </button>
              <div className="flex items-center gap-2 text-sm">
                <Trophy className="w-5 h-5 text-amber-500" />
                <span className="font-semibold text-slate-900">0 pts</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6">
        {/* ── PAGE TITLE + SEARCH ─────────────────────── */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-gradient-to-br from-blue-600 to-blue-500 rounded-xl flex items-center justify-center shadow-sm">
              <Newspaper className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">
                News &amp; Communication
              </h1>
              <p className="text-sm text-slate-500">
                Market intelligence and updates affecting your business
              </p>
            </div>
          </div>

          <div className="relative hidden md:block">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search news…"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 w-64 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>



        {/* ── FEATURED ARTICLE (only on "All News") ───── */}
        {activeFilter === "all" && featuredArticle && (
          <button
            onClick={() => setSelectedArticle(featuredArticle)}
            className="w-full text-left mb-6 group"
          >
            <div
              className={`relative overflow-hidden rounded-2xl border ${
                TYPE_STYLES[featuredArticle.type].border
              } ${
                TYPE_STYLES[featuredArticle.type].bg
              } p-6 md:p-8 transition-all hover:shadow-md`}
            >
              <div className="absolute top-4 right-4">
                <span className="flex items-center gap-1.5 px-3 py-1 bg-red-600 text-white text-xs font-bold rounded-full animate-pulse">
                  <Zap className="w-3 h-3" />
                  BREAKING
                </span>
              </div>

              <div className="max-w-3xl">
                <div className="flex items-center gap-2 text-xs text-slate-500 mb-3">
                  <span className="font-medium">{featuredArticle.source}</span>
                  <span>•</span>
                  <span>{featuredArticle.date}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {featuredArticle.readTime}
                  </span>
                </div>

                <h2 className="text-xl md:text-2xl font-bold text-slate-900 mb-3 group-hover:text-blue-600 transition-colors leading-tight">
                  {featuredArticle.headline}
                </h2>

                <p className="text-slate-600 leading-relaxed mb-4">
                  {featuredArticle.summary}
                </p>

                <div className="flex flex-wrap items-center gap-2">
                  {featuredArticle.impact && (
                    <span
                      className={`px-3 py-1 text-xs font-semibold rounded-full ${
                        IMPACT_BADGE[featuredArticle.impact].cls
                      }`}
                    >
                      {IMPACT_BADGE[featuredArticle.impact].label}
                    </span>
                  )}
                  {featuredArticle.impactAreas?.map((area) => (
                    <span
                      key={area}
                      className="px-2.5 py-1 text-xs font-medium rounded-full bg-white/80 text-slate-600 border border-slate-200"
                    >
                      {area}
                    </span>
                  ))}
                  <span className="ml-auto text-sm text-blue-600 font-medium flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    Read full article <ChevronRight className="w-4 h-4" />
                  </span>
                </div>
              </div>
            </div>
          </button>
        )}

        {/* ── NEWS GRID ───────────────────────────────── */}
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
          {restArticles.map((article) => {
            const style = TYPE_STYLES[article.type];
            const Icon = style.icon;

            return (
              <button
                key={article.id}
                onClick={() => setSelectedArticle(article)}
                className="text-left group"
              >
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden h-full flex flex-col transition-all hover:shadow-md hover:border-slate-300">
                  {/* Type banner */}
                  <div
                    className={`${style.bg} ${style.border} border-b px-4 py-2.5 flex items-center justify-between`}
                  >
                    <div className="flex items-center gap-2">
                      <Icon className={`w-4 h-4 ${style.text}`} />
                      <span
                        className={`text-xs font-semibold uppercase tracking-wider ${style.text}`}
                      >
                        {style.label}
                      </span>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleBookmark(article.id);
                      }}
                      className={`p-1 rounded transition-colors ${
                        bookmarked.has(article.id)
                          ? "text-amber-500"
                          : "text-slate-300 hover:text-slate-500"
                      }`}
                    >
                      <Bookmark className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Card body */}
                  <div className="p-4 flex-1 flex flex-col">
                    <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
                      <span>{article.source}</span>
                      <span>•</span>
                      <span>{article.date}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {article.readTime}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900 mb-2 leading-snug group-hover:text-blue-600 transition-colors line-clamp-2">
                      {article.headline}
                    </h3>

                    <p className="text-xs text-slate-500 leading-relaxed flex-1 line-clamp-3">
                      {article.summary}
                    </p>

                    {/* Impact tags */}
                    <div className="flex flex-wrap items-center gap-1.5 mt-3 pt-3 border-t border-slate-100">
                      {article.impact && (
                        <span
                          className={`px-2 py-0.5 text-[10px] font-semibold rounded-full ${
                            IMPACT_BADGE[article.impact].cls
                          }`}
                        >
                          {article.impact === "positive" ? (
                            <TrendingUp className="w-3 h-3 inline mr-0.5 -mt-0.5" />
                          ) : article.impact === "negative" ? (
                            <TrendingDown className="w-3 h-3 inline mr-0.5 -mt-0.5" />
                          ) : null}
                          {article.impact}
                        </span>
                      )}
                      {article.impactAreas?.slice(0, 2).map((area) => (
                        <span
                          key={area}
                          className="px-2 py-0.5 text-[10px] font-medium rounded-full bg-slate-100 text-slate-500"
                        >
                          {area}
                        </span>
                      ))}
                      {(article.impactAreas?.length || 0) > 2 && (
                        <span className="text-[10px] text-slate-400">
                          +{(article.impactAreas?.length || 0) - 2}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* ── EMPTY STATE ─────────────────────────────── */}
        {filtered.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Newspaper className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-1">
              No articles found
            </h3>
            <p className="text-sm text-slate-500">
              Try adjusting your filters or search query
            </p>
            <button
              onClick={() => {
                setActiveFilter("all");
                setSearchQuery("");
              }}
              className="mt-4 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-xl hover:bg-blue-700 transition"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
