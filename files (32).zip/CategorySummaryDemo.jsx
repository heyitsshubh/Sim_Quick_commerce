import { useState } from "react";
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const SEGMENTS = ["premium", "standard", "basic", "discount"];

const SEGMENT_META = {
  premium: { label: "Premium", color: "#8b5cf6", bg: "#f5f3ff", border: "#c4b5fd", iconBg: "#ede9fe", emoji: "👑" },
  standard: { label: "Standard", color: "#2563eb", bg: "#eff6ff", border: "#bfdbfe", iconBg: "#dbeafe", emoji: "⭐" },
  basic: { label: "Basic", color: "#10b981", bg: "#ecfdf5", border: "#a7f3d0", iconBg: "#d1fae5", emoji: "📦" },
  discount: { label: "Discount", color: "#f59e0b", bg: "#fffbeb", border: "#fde68a", iconBg: "#fef3c7", emoji: "🏷️" },
};

const CATEGORIES = [
  { _id: "1", name: "Fruits & Vegetables" },
  { _id: "2", name: "Dairy & Eggs" },
  { _id: "3", name: "Cooking Staples" },
  { _id: "4", name: "Packaged Food & Snacks" },
  { _id: "5", name: "Beverages" },
];

const mockSegmentData = () => ({
  premium: {
    coreScore: 72.4, multiplierOnCoreScore: 1.35, totalScore: 4280,
    market: { marketShare: 18.2, totalMarketSize: 2940000, yourSales: 755463, directDemand: 620000 },
    breakdown: [
      { keyIndicator: "Product Range", achievedPoints: 78, totalScore: 312 },
      { keyIndicator: "Supply Chain", achievedPoints: 65, totalScore: 260 },
      { keyIndicator: "Customer Experience", achievedPoints: 82, totalScore: 328 },
    ],
    competitors: [
      { name: "You", score: 4280 }, { name: "Competitor A", score: 5120 }, { name: "Competitor B", score: 3890 },
    ],
  },
  standard: {
    coreScore: 68.1, multiplierOnCoreScore: 1.22, totalScore: 3650,
    market: { marketShare: 22.5, totalMarketSize: 2362500, yourSales: 660797, directDemand: 540000 },
    breakdown: [
      { keyIndicator: "Product Range", achievedPoints: 72, totalScore: 288 },
      { keyIndicator: "Supply Chain", achievedPoints: 70, totalScore: 280 },
      { keyIndicator: "Customer Experience", achievedPoints: 68, totalScore: 272 },
    ],
    competitors: [
      { name: "You", score: 3650 }, { name: "Competitor A", score: 4200 }, { name: "Competitor C", score: 3100 },
    ],
  },
  basic: {
    coreScore: 55.3, multiplierOnCoreScore: 1.08, totalScore: 2180,
    market: { marketShare: 12.8, totalMarketSize: 2205000, yourSales: 282240, directDemand: 410000 },
    breakdown: [
      { keyIndicator: "Product Range", achievedPoints: 55, totalScore: 220 },
      { keyIndicator: "Supply Chain", achievedPoints: 58, totalScore: 232 },
      { keyIndicator: "Customer Experience", achievedPoints: 52, totalScore: 208 },
    ],
    competitors: [
      { name: "You", score: 2180 }, { name: "Competitor B", score: 2900 }, { name: "Competitor D", score: 2450 },
    ],
  },
  discount: {
    coreScore: 41.2, multiplierOnCoreScore: 0.95, totalScore: 1420,
    market: { marketShare: 8.4, totalMarketSize: 2205000, yourSales: 185220, directDemand: 380000 },
    breakdown: [
      { keyIndicator: "Product Range", achievedPoints: 40, totalScore: 160 },
      { keyIndicator: "Supply Chain", achievedPoints: 45, totalScore: 180 },
      { keyIndicator: "Customer Experience", achievedPoints: 38, totalScore: 152 },
    ],
    competitors: [
      { name: "You", score: 1420 }, { name: "Competitor C", score: 2800 }, { name: "Competitor D", score: 1900 },
    ],
  },
});

function buildBubbles(data) {
  const pts = [];
  SEGMENTS.forEach((seg) => {
    const d = data[seg];
    if (!d) return;
    const qualityY = seg === "premium" ? 7 : seg === "standard" ? 5 : seg === "basic" ? 3 : 1;
    const score = d.totalScore || 0;
    const share = d.market?.marketShare || 0;
    const px = seg === "discount" ? 150 : seg === "basic" ? 320 : seg === "standard" ? 510 : 680;
    pts.push({ name: `You (${SEGMENT_META[seg].label})`, segment: seg, x: px + score * 0.02, y: qualityY, z: Math.max(share * 40, 80), isYou: true, share, score });
    d.competitors?.filter((c) => !c.name.toLowerCase().includes("you")).forEach((c, i) => {
      pts.push({ name: c.name, segment: seg, x: px + 30 + i * 60 + c.score * 0.01, y: qualityY + (i % 2 ? 0.4 : -0.3), z: Math.max(c.score * 0.2, 50), isYou: false, score: c.score, share: 0 });
    });
  });
  return pts;
}

function DonutRing({ percent, color, size = 130 }) {
  const r = 50;
  const circ = 2 * Math.PI * r;
  const dash = (percent / 100) * circ;
  return (
    <svg viewBox="0 0 120 120" style={{ width: size, height: size, transform: "rotate(-90deg)" }}>
      <circle cx="60" cy="60" r={r} fill="none" stroke="#e2e8f0" strokeWidth="8" />
      <circle cx="60" cy="60" r={r} fill="none" stroke={color} strokeWidth="8"
        strokeDasharray={`${dash} ${circ - dash}`} strokeLinecap="round"
        style={{ transition: "stroke-dasharray 1s ease" }} />
    </svg>
  );
}

function BubbleTooltip({ active, payload }) {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  return (
    <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 12, padding: "10px 14px", boxShadow: "0 4px 20px rgba(0,0,0,0.08)", fontSize: 13 }}>
      <div style={{ fontWeight: 700, color: "#0f172a", marginBottom: 2 }}>{d.name}</div>
      <div style={{ color: "#64748b", textTransform: "capitalize", marginBottom: 6 }}>{d.segment} segment</div>
      <div>Score: <b>{d.score?.toLocaleString("en-IN")}</b></div>
      {d.isYou && <div>Market Share: <b>{d.share?.toFixed(1)}%</b></div>}
    </div>
  );
}

export default function App() {
  const [activeCategory, setActiveCategory] = useState(null);
  const [activeSegment, setActiveSegment] = useState(null);
  const [expandedCat, setExpandedCat] = useState(null);

  const segData = activeCategory ? mockSegmentData() : null;
  const showSummary = activeCategory && !activeSegment;
  const showDetail = activeCategory && activeSegment;

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg, #f8fafc 0%, #eff6ff 50%, #f8fafc 100%)", fontFamily: "'Segoe UI', system-ui, -apple-system, sans-serif" }}>

      {/* TOP NAV */}
      <div style={{ display: "flex", justifyContent: "center", paddingTop: 20, paddingLeft: 16, paddingRight: 16 }}>
        <div style={{ display: "flex", gap: 6, padding: "10px 14px", borderRadius: 16, background: "rgba(255,255,255,0.85)", backdropFilter: "blur(20px)", border: "1px solid rgba(255,255,255,0.5)", boxShadow: "0 8px 30px rgba(0,0,0,0.06)" }}>
          {["Profile", "Business Plan", "Decisions", "Results", "Analysis", "Communication"].map((t) => (
            <div key={t} style={{ padding: "8px 18px", borderRadius: 12, fontSize: 14, fontWeight: 600, cursor: "pointer",
              ...(t === "Analysis" ? { background: "linear-gradient(135deg, #2563eb, #4f46e5)", color: "#fff", boxShadow: "0 4px 12px rgba(37,99,235,0.3)" } : { color: "#0f172a" }) }}>
              {t}
            </div>
          ))}
        </div>
      </div>

      {/* ROUND HEADER */}
      <div style={{ maxWidth: 1200, margin: "16px auto 0", padding: "0 24px" }}>
        <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 12, padding: "16px 20px", boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <h2 style={{ fontSize: 20, fontWeight: 700, color: "#0f172a", margin: 0 }}>Round 1 of 8</h2>
              <p style={{ fontSize: 13, color: "#64748b", margin: "4px 0 0" }}>Foundation: Fruits, dairy, cooking staples, snacks, beverages</p>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 18 }}>🏆</span>
              <span style={{ fontWeight: 700, fontSize: 14, color: "#0f172a" }}>0 pts</span>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 12, overflowX: "auto" }}>
            {[1,2,3,4,5,6,7,8].map((r) => (
              <div key={r} style={{ padding: "6px 14px", borderRadius: 8, fontSize: 13, fontWeight: 600, whiteSpace: "nowrap",
                background: r === 1 ? "#2563eb" : "#f1f5f9", color: r === 1 ? "#fff" : "#94a3b8" }}>
                {r <= 1 ? "🔓" : "🔒"} Round {r}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* MAIN */}
      <div style={{ maxWidth: 1200, margin: "24px auto 0", padding: "0 24px 48px", display: "flex", gap: 24 }}>

        {/* SIDEBAR */}
        <div style={{ width: 280, flexShrink: 0, background: "#fff", border: "1px solid #e2e8f0", borderRadius: 16, padding: 16, alignSelf: "flex-start", position: "sticky", top: 24, boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}>
          <h3 style={{ fontSize: 15, fontWeight: 800, letterSpacing: 1.5, color: "#0f172a", margin: "0 0 16px 8px" }}>CATEGORIES</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {CATEGORIES.map((cat) => {
              const isActive = activeCategory?._id === cat._id;
              const isExpanded = expandedCat === cat._id;
              return (
                <div key={cat._id}>
                  <div style={{ display: "flex", alignItems: "center", borderRadius: 12, cursor: "pointer", transition: "all 0.2s",
                    ...(isActive ? { background: "linear-gradient(135deg, #2563eb, #3b82f6)", color: "#fff", boxShadow: "0 2px 8px rgba(37,99,235,0.25)" } : { color: "#334155" }) }}
                    onMouseEnter={(e) => { if (!isActive) e.currentTarget.style.background = "#f1f5f9"; }}
                    onMouseLeave={(e) => { if (!isActive) e.currentTarget.style.background = isActive ? "" : "transparent"; }}>
                    <div onClick={() => { setActiveCategory(cat); setActiveSegment(null); setExpandedCat(cat._id); }}
                      style={{ flex: 1, padding: "10px 12px", display: "flex", alignItems: "center", gap: 10 }}>
                      <span style={{ width: 7, height: 7, borderRadius: "50%", background: isActive ? "#fff" : "#94a3b8" }} />
                      <span style={{ fontSize: 13, fontWeight: 600 }}>{cat.name}</span>
                    </div>
                    <div onClick={() => setExpandedCat(isExpanded ? null : cat._id)} style={{ padding: "10px 12px", cursor: "pointer" }}>
                      <span style={{ display: "inline-block", transform: isExpanded ? "rotate(90deg)" : "rotate(0)", transition: "transform 0.3s", fontSize: 14, color: isActive ? "#fff" : "#94a3b8" }}>▶</span>
                    </div>
                  </div>
                  {isExpanded && (
                    <div style={{ marginLeft: 28, display: "flex", flexWrap: "wrap", gap: 6, padding: "8px 0" }}>
                      {SEGMENTS.map((seg) => {
                        const active = activeSegment === seg && activeCategory?._id === cat._id;
                        return (
                          <button key={seg} onClick={() => { setActiveCategory(cat); setActiveSegment(seg); }}
                            style={{ padding: "5px 12px", fontSize: 11, fontWeight: 700, borderRadius: 20, border: "none", cursor: "pointer", textTransform: "capitalize", transition: "all 0.2s",
                              ...(active ? { background: "#10b981", color: "#fff", boxShadow: "0 2px 6px rgba(16,185,129,0.3)" } : { background: "#f1f5f9", color: "#64748b" }) }}>
                            {seg}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* CONTENT */}
        <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 24 }}>

          {!activeCategory && (
            <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 16, padding: "64px 24px", textAlign: "center" }}>
              <div style={{ width: 64, height: 64, background: "#eff6ff", borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", fontSize: 28 }}>🏆</div>
              <h3 style={{ fontSize: 20, fontWeight: 700, color: "#0f172a", margin: "0 0 8px" }}>Select a Category</h3>
              <p style={{ fontSize: 14, color: "#64748b", maxWidth: 400, margin: "0 auto" }}>Choose a product category from the sidebar to view market analysis, positioning matrix, and segment-level performance.</p>
            </div>
          )}

          {/* ═══ SUMMARY ═══ */}
          {showSummary && segData && (() => {
            const bubbles = buildBubbles(segData);
            const youPts = bubbles.filter((b) => b.isYou);
            const compPts = bubbles.filter((b) => !b.isYou);

            let totalScore = 0, avgMult = 0, avgShare = 0, totalSales = 0, totalDemand = 0, cnt = 0;
            SEGMENTS.forEach((s) => {
              const d = segData[s];
              if (!d) return;
              totalScore += d.totalScore || 0;
              avgMult += d.multiplierOnCoreScore || 0;
              avgShare += d.market?.marketShare || 0;
              totalSales += d.market?.yourSales || 0;
              totalDemand += d.market?.totalMarketSize || 0;
              cnt++;
            });
            if (cnt > 0) { avgMult /= cnt; avgShare /= cnt; }

            return (
              <>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <h2 style={{ fontSize: 24, fontWeight: 800, color: "#0f172a", margin: 0 }}>{activeCategory.name}</h2>
                    <p style={{ fontSize: 13, color: "#64748b", margin: "4px 0 0" }}>Category overview across all pricing segments</p>
                  </div>
                  <span style={{ padding: "6px 14px", background: "#eff6ff", border: "1px solid #bfdbfe", borderRadius: 20, fontSize: 12, fontWeight: 700, color: "#2563eb" }}>{cnt} Active Segments</span>
                </div>

                {/* KPIs */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
                  {[
                    { label: "Total Score", value: totalScore.toLocaleString("en-IN"), sub: "Across all segments", bg: "#eff6ff", border: "#bfdbfe", color: "#2563eb", emoji: "📈" },
                    { label: "Avg Multiplier", value: `×${avgMult.toFixed(2)}`, sub: "Decision impact", bg: "#ecfdf5", border: "#a7f3d0", color: "#10b981", emoji: "🎯" },
                    { label: "Avg Market Share", value: `${avgShare.toFixed(1)}%`, sub: "Your position", bg: "#f5f3ff", border: "#c4b5fd", color: "#8b5cf6", emoji: "🛒" },
                    { label: "Total Sales", value: totalSales.toLocaleString("en-IN"), sub: `of ${totalDemand.toLocaleString("en-IN")} demand`, bg: "#fffbeb", border: "#fde68a", color: "#d97706", emoji: "💰" },
                  ].map((k, i) => (
                    <div key={i} style={{ background: k.bg, border: `1px solid ${k.border}`, borderRadius: 14, padding: 18 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                        <span style={{ fontSize: 20 }}>{k.emoji}</span>
                        <span style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: 0.5 }}>{k.label}</span>
                      </div>
                      <div style={{ fontSize: 26, fontWeight: 800, color: k.color }}>{k.value}</div>
                      <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 2 }}>{k.sub}</div>
                    </div>
                  ))}
                </div>

                {/* ── MARKET: 4 SEGMENT CIRCLES ── */}
                <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 16, padding: 24, boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}>
                  <h3 style={{ fontSize: 18, fontWeight: 700, color: "#0f172a", margin: "0 0 4px" }}>Market</h3>
                  <p style={{ fontSize: 12, color: "#64748b", margin: "0 0 24px" }}>
                    Each circle shows the total segment size and your company's sales. Click on a circle to drill into that segment.
                  </p>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
                    {SEGMENTS.map((seg) => {
                      const d = segData[seg];
                      if (!d?.market) return null;
                      const m = SEGMENT_META[seg];
                      const share = d.market.marketShare;
                      return (
                        <div key={seg} onClick={() => setActiveSegment(seg)}
                          style={{ display: "flex", flexDirection: "column", alignItems: "center", background: m.bg, border: `1px solid ${m.border}`, borderRadius: 16, padding: "24px 16px", cursor: "pointer", transition: "all 0.2s" }}
                          onMouseEnter={(e) => { e.currentTarget.style.boxShadow = "0 8px 24px rgba(0,0,0,0.08)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
                          onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "none"; e.currentTarget.style.transform = "translateY(0)"; }}>

                          <div style={{ position: "relative", marginBottom: 12 }}>
                            <DonutRing percent={share} color={m.color} size={120} />
                            <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
                              <div style={{ width: 36, height: 36, background: m.iconBg, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 2, fontSize: 16 }}>
                                {m.emoji}
                              </div>
                              <span style={{ fontSize: 16, fontWeight: 800, color: m.color }}>{share.toFixed(1)}%</span>
                            </div>
                          </div>

                          <h4 style={{ fontSize: 15, fontWeight: 700, color: "#0f172a", margin: "0 0 12px" }}>{m.label}</h4>

                          <div style={{ width: "100%", borderTop: "1px solid #e2e8f0", paddingTop: 10 }}>
                            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 5 }}>
                              <span style={{ color: "#64748b" }}>Your sales</span>
                              <span style={{ fontWeight: 700, color: m.color }}>{d.market.yourSales.toLocaleString("en-IN")}</span>
                            </div>
                            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12 }}>
                              <span style={{ color: "#64748b" }}>Total demand</span>
                              <span style={{ fontWeight: 700, color: "#334155" }}>{d.market.totalMarketSize.toLocaleString("en-IN")}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* ── POSITIONING MATRIX ── */}
                <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 16, padding: 24, boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}>
                  <h3 style={{ fontSize: 18, fontWeight: 700, color: "#0f172a", margin: "0 0 4px" }}>Positioning Matrix</h3>
                  <p style={{ fontSize: 12, color: "#64748b", margin: "0 0 8px" }}>
                    Compare yourself against competitors. X-axis = Price Index, Y-axis = Quality. Bubble size = relative market share.
                  </p>
                  <div style={{ background: "#fffbeb", border: "1px solid #fde68a", borderRadius: 8, padding: "8px 12px", fontSize: 12, color: "#92400e", marginBottom: 20 }}>
                    Competitor identities hidden — invest in Market Analysis to reveal names.
                  </div>
                  <div style={{ height: 340 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <ScatterChart margin={{ top: 10, right: 30, bottom: 25, left: 10 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                        <XAxis type="number" dataKey="x" name="Price" tick={{ fontSize: 11, fill: "#64748b" }}
                          label={{ value: "Price Index (₹)", position: "bottom", offset: 5, style: { fontSize: 11, fill: "#94a3b8" } }} />
                        <YAxis type="number" dataKey="y" name="Quality" domain={[0, 8]} ticks={[1, 2, 3, 4, 5, 6, 7]}
                          tickFormatter={(v) => "★".repeat(Math.round(v))} tick={{ fontSize: 9, fill: "#64748b" }}
                          label={{ value: "Quality", angle: -90, position: "insideLeft", offset: 10, style: { fontSize: 11, fill: "#94a3b8" } }} />
                        <ZAxis type="number" dataKey="z" range={[30, 500]} />
                        <Tooltip content={<BubbleTooltip />} />
                        <Scatter name="You" data={youPts}>
                          {youPts.map((e, i) => (
                            <Cell key={i} fill={SEGMENT_META[e.segment].color} fillOpacity={0.85} stroke={SEGMENT_META[e.segment].color} strokeWidth={2} />
                          ))}
                        </Scatter>
                        <Scatter name="Competitors" data={compPts} shape="diamond">
                          {compPts.map((e, i) => (
                            <Cell key={i} fill={SEGMENT_META[e.segment].color} fillOpacity={0.25} stroke={SEGMENT_META[e.segment].color} strokeWidth={1.5} />
                          ))}
                        </Scatter>
                      </ScatterChart>
                    </ResponsiveContainer>
                  </div>
                  <div style={{ display: "flex", justifyContent: "center", gap: 20, marginTop: 12, flexWrap: "wrap" }}>
                    {SEGMENTS.map((s) => (
                      <div key={s} style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span style={{ width: 10, height: 10, borderRadius: "50%", background: SEGMENT_META[s].color }} />
                        <span style={{ fontSize: 12, color: "#64748b" }}>{SEGMENT_META[s].label}</span>
                      </div>
                    ))}
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginLeft: 12, paddingLeft: 12, borderLeft: "1px solid #e2e8f0" }}>
                      <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#334155" }} />
                      <span style={{ fontSize: 12, color: "#64748b" }}>You (solid)</span>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ width: 10, height: 10, background: "#cbd5e1", transform: "rotate(45deg)" }} />
                      <span style={{ fontSize: 12, color: "#64748b" }}>Competitors</span>
                    </div>
                  </div>
                </div>

                {/* ── SEGMENT CARDS ── */}
                <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 16, padding: 24, boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}>
                  <h3 style={{ fontSize: 18, fontWeight: 700, color: "#0f172a", margin: "0 0 4px" }}>Segment Breakdown</h3>
                  <p style={{ fontSize: 12, color: "#64748b", margin: "0 0 20px" }}>Click any segment to view detailed scoring, multipliers, and competitor analysis.</p>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
                    {SEGMENTS.map((seg) => {
                      const d = segData[seg];
                      if (!d) return null;
                      const m = SEGMENT_META[seg];
                      const score = d.totalScore || 0;
                      const share = d.market?.marketShare || 0;
                      const mult = d.multiplierOnCoreScore || 1;
                      return (
                        <div key={seg} onClick={() => setActiveSegment(seg)}
                          style={{ border: "1px solid #e2e8f0", borderRadius: 14, padding: 20, cursor: "pointer", transition: "all 0.2s" }}
                          onMouseEnter={(e) => { e.currentTarget.style.borderColor = "#93c5fd"; e.currentTarget.style.boxShadow = "0 4px 16px rgba(37,99,235,0.1)"; }}
                          onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#e2e8f0"; e.currentTarget.style.boxShadow = "none"; }}>
                          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                            <span style={{ padding: "4px 10px", fontSize: 11, fontWeight: 700, borderRadius: 20, background: m.color + "18", color: m.color }}>{m.label}</span>
                            <span style={{ color: "#cbd5e1", fontSize: 16 }}>▶</span>
                          </div>
                          <div style={{ fontSize: 28, fontWeight: 800, color: "#0f172a" }}>{score.toLocaleString("en-IN")}</div>
                          <div style={{ fontSize: 11, color: "#64748b", marginBottom: 14 }}>Total Score</div>
                          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 6 }}>
                            <span style={{ color: "#64748b" }}>Market Share</span>
                            <span style={{ fontWeight: 700, color: "#334155" }}>{share.toFixed(1)}%</span>
                          </div>
                          <div style={{ height: 6, background: "#f1f5f9", borderRadius: 4, overflow: "hidden", marginBottom: 10 }}>
                            <div style={{ height: "100%", borderRadius: 4, width: `${Math.min(share, 100)}%`, background: m.color, transition: "width 0.7s" }} />
                          </div>
                          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12 }}>
                            <span style={{ color: "#64748b" }}>Multiplier</span>
                            <span style={{ fontWeight: 700, color: "#10b981" }}>×{mult.toFixed(2)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </>
            );
          })()}

          {/* ═══ DETAIL ═══ */}
          {showDetail && segData && (() => {
            const d = segData[activeSegment];
            if (!d) return null;
            const m = SEGMENT_META[activeSegment];
            return (
              <>
                <button onClick={() => setActiveSegment(null)}
                  style={{ fontSize: 13, color: "#2563eb", fontWeight: 600, background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, padding: 0 }}>
                  ◀ Back to {activeCategory.name} Summary
                </button>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <h2 style={{ fontSize: 24, fontWeight: 800, color: "#0f172a", margin: 0 }}>{activeCategory.name}</h2>
                  <span style={{ padding: "4px 14px", background: "#d1fae5", color: "#065f46", fontSize: 13, fontWeight: 700, borderRadius: 20 }}>{m.label}</span>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
                  {[
                    { label: "Core Score", value: d.coreScore.toFixed(1), bg: "#eff6ff", border: "#bfdbfe", color: "#2563eb" },
                    { label: "Multiplier", value: `×${d.multiplierOnCoreScore.toFixed(2)}`, bg: "#ecfdf5", border: "#a7f3d0", color: "#10b981" },
                    { label: "Total Score", value: d.totalScore.toLocaleString(), bg: "#fffbeb", border: "#fde68a", color: "#d97706" },
                    { label: "Market Share", value: `${d.market.marketShare.toFixed(1)}%`, bg: "#f5f3ff", border: "#c4b5fd", color: "#8b5cf6" },
                  ].map((k, i) => (
                    <div key={i} style={{ background: k.bg, border: `1px solid ${k.border}`, borderRadius: 14, padding: 18 }}>
                      <p style={{ fontSize: 11, fontWeight: 700, color: "#64748b", margin: "0 0 4px" }}>{k.label}</p>
                      <p style={{ fontSize: 26, fontWeight: 800, color: k.color, margin: 0 }}>{k.value}</p>
                    </div>
                  ))}
                </div>
                <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 16, padding: 24 }}>
                  <h3 style={{ fontSize: 16, fontWeight: 700, color: "#0f172a", margin: "0 0 16px" }}>Core Score Breakdown</h3>
                  {d.breakdown.map((b, i) => (
                    <div key={i} style={{ marginBottom: 14 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 4 }}>
                        <span style={{ color: "#64748b" }}>{b.keyIndicator}</span>
                        <span style={{ fontWeight: 700, color: "#0f172a" }}>{b.totalScore}</span>
                      </div>
                      <div style={{ height: 10, background: "#f1f5f9", borderRadius: 6 }}>
                        <div style={{ height: "100%", background: "#2563eb", borderRadius: 6, width: `${Math.min(b.achievedPoints, 100)}%`, transition: "width 0.7s" }} />
                      </div>
                    </div>
                  ))}
                </div>
              </>
            );
          })()}
        </div>
      </div>
    </div>
  );
}
