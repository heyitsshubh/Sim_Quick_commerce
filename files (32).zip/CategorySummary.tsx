/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  ScatterChart, Scatter, XAxis, YAxis, ZAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Cell,
} from "recharts";
import {
  TrendingUp, Target, ShoppingCart, DollarSign, ChevronRight,
  Loader2, Crown, Star, Package, Tag,
} from "lucide-react";

type Segment = "premium" | "standard" | "basic" | "discount";
const SEGMENTS: Segment[] = ["premium", "standard", "basic", "discount"];

interface CategorySummaryProps {
  category: { _id: string; name: string };
  segmentData: Record<string, any> | null;
  loading: boolean;
  onSegmentClick: (seg: Segment) => void;
}

const SEGMENT_COLORS: Record<string, string> = {
  premium: "#8b5cf6", standard: "#2563eb", basic: "#10b981", discount: "#f59e0b",
};

const SEGMENT_CONFIG: Record<string, { icon: any; desc: string; bg: string; border: string; iconBg: string; text: string }> = {
  premium:  { icon: Crown,   desc: "High-end products, imported & organic focus",  bg: "bg-violet-50",  border: "border-violet-200",  iconBg: "bg-violet-100",  text: "text-violet-700" },
  standard: { icon: Star,    desc: "Balanced quality for mainstream consumers",     bg: "bg-blue-50",    border: "border-blue-200",    iconBg: "bg-blue-100",    text: "text-blue-700" },
  basic:    { icon: Package, desc: "Essentials at competitive price points",        bg: "bg-emerald-50", border: "border-emerald-200", iconBg: "bg-emerald-100", text: "text-emerald-700" },
  discount: { icon: Tag,     desc: "Value-driven, price-conscious shoppers",        bg: "bg-amber-50",  border: "border-amber-200",  iconBg: "bg-amber-100",  text: "text-amber-700" },
};

/* ─── Positioning Matrix ─── */
function buildPositioningData(segmentData: Record<string, any>) {
  const points: any[] = [];
  SEGMENTS.forEach((seg) => {
    const d = segmentData[seg];
    if (!d) return;
    const score = d.totalScore ?? d.finalScore ?? d.coreScore ?? 0;
    const share = d.market?.marketShare ?? 0;
    const qualityStars = seg === "premium" ? 7 : seg === "standard" ? 5 : seg === "basic" ? 3 : 1;
    const priceIndex = seg === "discount" ? 150 + score * 0.3
      : seg === "basic" ? 300 + score * 0.2
      : seg === "standard" ? 500 + score * 0.15
      : 650 + score * 0.1;

    points.push({ name: `You (${seg.charAt(0).toUpperCase() + seg.slice(1)})`, segment: seg, x: Math.round(priceIndex), y: qualityStars, z: Math.max(share * 50, 80), isYou: true, share, score });

    d.competitors?.filter((c: any) => !c.name.toLowerCase().includes("you")).slice(0, 2).forEach((c: any, idx: number) => {
      const px = seg === "discount" ? 120 + c.score * 0.3 + idx * 40
        : seg === "basic" ? 250 + c.score * 0.2 + idx * 50
        : seg === "standard" ? 450 + c.score * 0.15 + idx * 60
        : 600 + c.score * 0.1 + idx * 50;
      points.push({ name: c.name, segment: seg, x: Math.round(px), y: qualityStars + (Math.random() * 0.8 - 0.4), z: Math.max(c.score * 0.3, 60), isYou: false, share: 0, score: c.score });
    });
  });
  return points;
}

const CustomTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-lg p-3 text-sm">
      <p className="font-semibold text-slate-900">{d.name}</p>
      <p className="text-slate-500 capitalize">{d.segment} segment</p>
      <div className="mt-1 space-y-0.5">
        <p>Score: <span className="font-semibold">{d.score?.toLocaleString("en-IN")}</span></p>
        {d.isYou && <p>Market Share: <span className="font-semibold">{d.share?.toFixed(1)}%</span></p>}
      </div>
    </div>
  );
};

/* ═══ MAIN ═══ */
export default function CategorySummary({ category, segmentData, loading, onSegmentClick }: CategorySummaryProps) {
  if (loading || !segmentData) {
    return (
      <div className="bg-white border border-slate-200 rounded-2xl p-12 flex flex-col items-center justify-center gap-3">
        <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
        <p className="text-slate-500 text-sm">Loading category analysis…</p>
      </div>
    );
  }

  const positioningData = buildPositioningData(segmentData);
  const youPoints = positioningData.filter((p) => p.isYou);
  const competitorPoints = positioningData.filter((p) => !p.isYou);

  let totalScore = 0, avgMultiplier = 0, avgShare = 0, totalSales = 0, totalDemand = 0, count = 0;
  SEGMENTS.forEach((seg) => {
    const d = segmentData[seg];
    if (!d) return;
    totalScore += d.totalScore ?? d.finalScore ?? 0;
    avgMultiplier += d.multiplierOnCoreScore ?? 0;
    avgShare += d.market?.marketShare ?? 0;
    totalSales += d.market?.yourSales ?? 0;
    totalDemand += d.market?.totalMarketSize ?? 0;
    count++;
  });
  if (count > 0) { avgMultiplier /= count; avgShare /= count; }

  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">{category.name}</h2>
          <p className="text-sm text-slate-500 mt-1">Category overview across all pricing segments</p>
        </div>
        <span className="px-3 py-1.5 bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold rounded-full">
          {count} Active Segments
        </span>
      </div>

      {/* KPI ROW */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <SummaryKpi label="Total Score" value={totalScore.toLocaleString("en-IN")} sub="Across all segments" icon={<TrendingUp className="w-5 h-5" />} color="blue" />
        <SummaryKpi label="Avg Multiplier" value={`×${avgMultiplier.toFixed(2)}`} sub="Decision impact" icon={<Target className="w-5 h-5" />} color="emerald" />
        <SummaryKpi label="Avg Market Share" value={`${avgShare.toFixed(1)}%`} sub="Your position" icon={<ShoppingCart className="w-5 h-5" />} color="violet" />
        <SummaryKpi label="Total Sales" value={totalSales.toLocaleString("en-IN")} sub={`of ${totalDemand.toLocaleString("en-IN")} demand`} icon={<DollarSign className="w-5 h-5" />} color="amber" />
      </div>

      {/* ───── MARKET CIRCLES (4 segments) ───── */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6">
        <div className="mb-5">
          <h3 className="text-lg font-bold text-slate-900">Market</h3>
          <p className="text-xs text-slate-500 mt-1">
            Each circle shows the total segment size and your company's sales. Click on a circle to drill into that segment.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
          {SEGMENTS.map((seg) => {
            const d = segmentData[seg];
            if (!d?.market) return null;
            const share = d.market.marketShare ?? 0;
            const sales = d.market.yourSales ?? 0;
            const demand = d.market.totalMarketSize ?? 0;
            const cfg = SEGMENT_CONFIG[seg];
            const Icon = cfg.icon;
            const r = 50;
            const circ = 2 * Math.PI * r;
            const dash = (share / 100) * circ;

            return (
              <button
                key={seg}
                onClick={() => onSegmentClick(seg)}
                className={`flex flex-col items-center ${cfg.bg} border ${cfg.border} rounded-2xl p-5 transition-all hover:shadow-lg hover:-translate-y-0.5 text-left`}
              >
                <div className="relative w-28 h-28 mb-3">
                  <svg viewBox="0 0 120 120" className="w-full h-full -rotate-90">
                    <circle cx="60" cy="60" r={r} fill="none" stroke="#e2e8f0" strokeWidth="8" />
                    <circle cx="60" cy="60" r={r} fill="none" stroke={SEGMENT_COLORS[seg]} strokeWidth="8"
                      strokeDasharray={`${dash} ${circ - dash}`} strokeLinecap="round" className="transition-all duration-1000" />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className={`w-9 h-9 ${cfg.iconBg} rounded-xl flex items-center justify-center mb-1`}>
                      <Icon className={`w-4 h-4 ${cfg.text}`} />
                    </div>
                    <span className={`text-base font-bold ${cfg.text}`}>{share.toFixed(1)}%</span>
                  </div>
                </div>

                <h4 className="text-sm font-bold text-slate-900 mb-0.5 capitalize">{seg}</h4>
                <p className="text-[10px] text-slate-500 text-center mb-3 leading-snug">{cfg.desc}</p>

                <div className={`w-full border-t ${cfg.border} pt-2.5 space-y-1.5`}>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Your sales</span>
                    <span className={`font-semibold ${cfg.text}`}>{sales.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Total demand</span>
                    <span className="font-semibold text-slate-700">{demand.toLocaleString("en-IN")}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ───── POSITIONING MATRIX ───── */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6">
        <div className="mb-5">
          <h3 className="text-lg font-bold text-slate-900">Positioning Matrix</h3>
          <p className="text-xs text-slate-500 mt-1">
            Compare yourself against competitors on Price (x-axis) and Quality (y-axis). Bubble size indicates relative market share.
          </p>
        </div>
        <div className="bg-amber-50 border border-amber-200 rounded-lg px-3 py-2.5 mb-5 text-xs text-amber-700">
          Competitor identities hidden — invest in Market Analysis to reveal names.
        </div>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 20, right: 30, bottom: 20, left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis type="number" dataKey="x" name="Price Index" tick={{ fontSize: 12, fill: "#64748b" }}
                label={{ value: "Price Index (₹)", position: "bottom", offset: 0, style: { fontSize: 12, fill: "#94a3b8" } }} />
              <YAxis type="number" dataKey="y" name="Quality" domain={[0, 8]} ticks={[1, 2, 3, 4, 5, 6, 7]}
                tickFormatter={(v: number) => "★".repeat(Math.round(v))} tick={{ fontSize: 10, fill: "#64748b" }}
                label={{ value: "Quality", angle: -90, position: "insideLeft", style: { fontSize: 12, fill: "#94a3b8" } }} />
              <ZAxis type="number" dataKey="z" range={[40, 400]} />
              <Tooltip content={<CustomTooltip />} />
              <Scatter name="You" data={youPoints} shape="circle">
                {youPoints.map((entry, idx) => (
                  <Cell key={idx} fill={SEGMENT_COLORS[entry.segment] || "#2563eb"} fillOpacity={0.85} stroke={SEGMENT_COLORS[entry.segment] || "#2563eb"} strokeWidth={2} />
                ))}
              </Scatter>
              <Scatter name="Competitors" data={competitorPoints} shape="diamond">
                {competitorPoints.map((entry, idx) => (
                  <Cell key={idx} fill={SEGMENT_COLORS[entry.segment] || "#94a3b8"} fillOpacity={0.3} stroke={SEGMENT_COLORS[entry.segment] || "#94a3b8"} strokeWidth={1} />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center gap-3 mt-4 flex-wrap">
          {SEGMENTS.map((seg) => (
            <div key={seg} className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: SEGMENT_COLORS[seg] }} />
              <span className="text-xs text-slate-600 capitalize">{seg}</span>
            </div>
          ))}
          <div className="flex items-center gap-1.5 ml-3 pl-3 border-l border-slate-200">
            <span className="w-3 h-3 rounded-full bg-slate-700" />
            <span className="text-xs text-slate-600">You (solid)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 bg-slate-300 rotate-45" />
            <span className="text-xs text-slate-600">Competitors</span>
          </div>
        </div>
      </div>

      {/* ───── SEGMENT CARDS ───── */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6">
        <div className="mb-5">
          <h3 className="text-lg font-bold text-slate-900">Segment Breakdown</h3>
          <p className="text-xs text-slate-500 mt-1">Click any segment to view detailed scoring, multipliers, and competitor analysis.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {SEGMENTS.map((seg) => {
            const d = segmentData[seg];
            if (!d) {
              return (
                <div key={seg} className="rounded-xl border border-dashed border-slate-200 p-5 text-center opacity-50">
                  <p className="text-sm font-semibold text-slate-400 capitalize">{seg}</p>
                  <p className="text-xs text-slate-400 mt-1">No data</p>
                </div>
              );
            }
            const score = d.totalScore ?? d.finalScore ?? 0;
            const share = d.market?.marketShare ?? 0;
            const mult = d.multiplierOnCoreScore ?? 1;
            return (
              <button key={seg} onClick={() => onSegmentClick(seg)}
                className="group text-left rounded-xl border border-slate-200 p-5 hover:border-blue-300 hover:shadow-md transition-all">
                <div className="flex items-center justify-between mb-3">
                  <span className="px-2.5 py-1 text-xs font-bold rounded-full capitalize"
                    style={{ backgroundColor: SEGMENT_COLORS[seg] + "18", color: SEGMENT_COLORS[seg] }}>{seg}</span>
                  <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-blue-500 transition-colors" />
                </div>
                <p className="text-2xl font-bold text-slate-900 mb-1">{score.toLocaleString("en-IN")}</p>
                <p className="text-xs text-slate-500 mb-3">Total Score</p>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Market Share</span>
                    <span className="font-semibold text-slate-700">{share.toFixed(1)}%</span>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full">
                    <div className="h-full rounded-full transition-all duration-700"
                      style={{ width: `${Math.min(share, 100)}%`, backgroundColor: SEGMENT_COLORS[seg] }} />
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Multiplier</span>
                    <span className="font-semibold text-emerald-600">×{mult.toFixed(2)}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ─── KPI Card ─── */
function SummaryKpi({ label, value, sub, icon, color }: { label: string; value: string; sub: string; icon: React.ReactNode; color: string }) {
  const colorMap: Record<string, { bg: string; border: string; text: string; iconBg: string }> = {
    blue:    { bg: "bg-blue-50",    border: "border-blue-200",    text: "text-blue-700",    iconBg: "bg-blue-100" },
    emerald: { bg: "bg-emerald-50", border: "border-emerald-200", text: "text-emerald-700", iconBg: "bg-emerald-100" },
    violet:  { bg: "bg-violet-50",  border: "border-violet-200",  text: "text-violet-700",  iconBg: "bg-violet-100" },
    amber:   { bg: "bg-amber-50",   border: "border-amber-200",   text: "text-amber-700",   iconBg: "bg-amber-100" },
  };
  const c = colorMap[color] || colorMap.blue;
  return (
    <div className={`${c.bg} border ${c.border} rounded-xl p-4`}>
      <div className="flex items-center gap-2 mb-2">
        <div className={`w-8 h-8 ${c.iconBg} rounded-lg flex items-center justify-center`}>
          <span className={c.text}>{icon}</span>
        </div>
        <p className="text-xs font-semibold text-slate-500">{label}</p>
      </div>
      <p className={`text-2xl font-bold ${c.text}`}>{value}</p>
      <p className="text-xs text-slate-400 mt-0.5">{sub}</p>
    </div>
  );
}
